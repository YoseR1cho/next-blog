import React from 'react';
import {notFound} from "next/navigation";

const Page = () => {
    notFound()
};

export default Page;
