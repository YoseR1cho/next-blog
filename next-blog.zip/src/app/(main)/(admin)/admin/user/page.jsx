"use client";
import React from "react";

const Page = () => {
    return (
        <>
            <div className='app-container'>
                <p>待开发~~~</p>
            </div>
        </>
    );
};

export default Page;
